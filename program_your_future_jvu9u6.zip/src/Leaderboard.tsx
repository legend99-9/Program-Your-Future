import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { motion } from "framer-motion";

export function Leaderboard({ language }: { language: string }) {
  const leaderboard = useQuery(api.questions.getLeaderboard) ?? [];

  const translations = {
    title: language === "ar" ? "لوحة المتصدرين 🏆" : "Leaderboard 🏆",
    points: language === "ar" ? "نقاط" : "points",
    personalities: {
      "Interested in Programming": language === "ar" ? "مهتم بالبرمجة" : "Interested in Programming",
      "Undecided": language === "ar" ? "متردد" : "Undecided",
      "Not Interested": language === "ar" ? "غير مهتم" : "Not Interested",
    }
  };

  return (
    <div className="bg-white/20 backdrop-blur-md rounded-xl p-8 text-white" dir={language === "ar" ? "rtl" : "ltr"}>
      <h2 className="text-3xl font-bold mb-8">{translations.title}</h2>
      <div className="space-y-4">
        {leaderboard.map((entry, index) => (
          <motion.div
            initial={{ opacity: 0, x: language === "ar" ? 20 : -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            key={index}
            className={`flex items-center gap-4 p-4 rounded-xl ${
              index === 0 
                ? "bg-gradient-to-r from-yellow-500/30 to-amber-500/30 border border-yellow-500/50" 
                : index === 1 
                ? "bg-gradient-to-r from-slate-400/30 to-gray-500/30 border border-slate-400/50"
                : index === 2
                ? "bg-gradient-to-r from-orange-700/30 to-orange-800/30 border border-orange-700/50"
                : "bg-white/10"
            }`}
          >
            <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl
              ${index === 0 ? "bg-yellow-500" : index === 1 ? "bg-slate-400" : index === 2 ? "bg-orange-700" : "bg-teal-500"}`}>
              {index + 1}
            </div>
            <div className="flex-1">
              <div className="font-semibold text-xl flex items-center gap-2">
                {entry.name}
                {index === 0 && "👑"}
              </div>
              <div className={`
                ${entry.personality === "Interested in Programming" ? "text-teal-200" : 
                  entry.personality === "Undecided" ? "text-purple-200" : "text-red-200"}
              `}>
                {translations.personalities[entry.personality as keyof typeof translations.personalities]}
              </div>
            </div>
            <div className="text-2xl font-bold flex items-center gap-2">
              {Math.round(entry.score)}
              <span className="text-sm font-normal opacity-70">{translations.points}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
