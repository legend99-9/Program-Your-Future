import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { motion } from "framer-motion";

export function Badges({ language }: { language: string }) {
  const progress = useQuery(api.badges.getBadgeProgress) ?? [];
  const userBadges = useQuery(api.badges.getUserBadges) ?? [];
  const initializeBadges = useMutation(api.badges.initializeBadges);

  const translations = {
    noBadges: language === "ar" ? "لا توجد شارات متاحة" : "No badges available",
    addBadges: language === "ar" ? "إضافة الشارات" : "Add Badges",
    badges: language === "ar" ? "الشارات 🎖️" : "Badges 🎖️",
  };

  if (progress.length === 0) {
    return (
      <div className="text-center bg-white/20 backdrop-blur-md rounded-xl p-8">
        <div className="text-xl mb-4 text-white">{translations.noBadges}</div>
        <button
          onClick={async () => {
            await initializeBadges();
          }}
          className="bg-teal-500 text-white px-6 py-3 rounded-xl hover:bg-teal-600
                     transition-colors duration-200 font-semibold"
        >
          {translations.addBadges}
        </button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-4xl mx-auto bg-white/20 backdrop-blur-md rounded-xl p-8 text-white"
      dir={language === "ar" ? "rtl" : "ltr"}
    >
      <h2 className="text-3xl font-bold mb-8">{translations.badges}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {progress.map((badge, index) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            key={badge.name}
            className={`p-6 rounded-xl ${
              userBadges.includes(badge.name)
                ? "bg-gradient-to-r from-teal-500/30 to-purple-500/30 border border-teal-500/50"
                : "bg-white/10"
            }`}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="text-4xl">{badge.icon}</div>
              <div>
                <h3 className="text-xl font-bold">
                  {language === "ar" ? badge.name_ar : badge.name}
                </h3>
                <p className="text-sm opacity-80">
                  {language === "ar" ? badge.description_ar : badge.description}
                </p>
              </div>
            </div>
            <div className="relative h-2 bg-white/20 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${badge.progress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-teal-500 to-purple-500"
              />
            </div>
            <div className="text-sm mt-2 text-right">{Math.round(badge.progress)}%</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
