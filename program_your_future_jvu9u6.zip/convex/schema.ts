import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  questions: defineTable({
    text_ar: v.string(),
    text_en: v.string(),
    order: v.number(),
  }).index("by_order", ["order"]),

  responses: defineTable({
    userId: v.id("users"),
    answers: v.array(v.object({
      questionId: v.id("questions"),
      response: v.number(),
    })),
    personality: v.string(),
    score: v.optional(v.number()),
    completed: v.boolean(),
  }).index("by_user", ["userId"]),

  profiles: defineTable({
    userId: v.id("users"),
    name: v.string(),
    language: v.string(),
    theme: v.optional(v.string()),
    soundEnabled: v.optional(v.boolean()),
    badges: v.optional(v.array(v.string())),
  }).index("by_user", ["userId"]),

  badges: defineTable({
    name: v.string(),
    name_ar: v.string(),
    description: v.string(),
    description_ar: v.string(),
    icon: v.string(),
    requiredScore: v.optional(v.number()),
    requiredCompletions: v.optional(v.number()),
    type: v.string(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
