import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Doc, Id } from "./_generated/dataModel";
import { api } from "./_generated/api";

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("questions")
      .withIndex("by_order")
      .collect();
  },
});

export const getLastResponse = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("responses")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .first();
  },
});

export const getLeaderboard = query({
  args: {},
  handler: async (ctx) => {
    const responses = await ctx.db
      .query("responses")
      .order("desc")
      .collect();
    
    const userBestScores = new Map<Id<"users">, Doc<"responses">>();
    for (const response of responses) {
      const existingScore = userBestScores.get(response.userId);
      if (!existingScore || (response.score ?? 0) > (existingScore.score ?? 0)) {
        userBestScores.set(response.userId, response);
      }
    }

    const profiles = await Promise.all(
      Array.from(userBestScores.keys()).map(userId => 
        ctx.db
          .query("profiles")
          .withIndex("by_user", q => q.eq("userId", userId))
          .first()
      )
    );

    const leaderboard = Array.from(userBestScores.values()).map((response, i) => {
      const profile = profiles[i];
      return {
        name: profile?.name ?? "Anonymous",
        personality: response.personality,
        score: response.score ?? 0
      };
    });

    return leaderboard.sort((a, b) => b.score - a.score).slice(0, 10);
  },
});

function calculatePersonality(avgScore: number): string {
  if (avgScore > 2.5) return "Not Interested";
  if (avgScore > 1.5) return "Undecided";
  return "Interested in Programming";
}

export const saveResponse = mutation({
  args: {
    answers: v.array(
      v.object({
        questionId: v.id("questions"),
        response: v.number(),
      })
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const score = args.answers.reduce((sum, a) => sum + a.response, 0);
    const avgScore = score / args.answers.length;
    const personality = calculatePersonality(avgScore);
    
    const result = await ctx.db.insert("responses", {
      userId,
      answers: args.answers,
      personality,
      score: avgScore,
      completed: true,
    });

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", q => q.eq("userId", userId))
      .first();

    if (!profile) return { personality, newBadges: [] };

    const badges = await ctx.db.query("badges").collect();
    const percentage = ((3 - avgScore) / 2) * 100;
    
    const earnedBadges = badges
      .filter((badge: Doc<"badges">) => 
        badge.type === "score" && 
        badge.requiredScore !== undefined && 
        percentage >= badge.requiredScore
      )
      .map((badge: Doc<"badges">) => badge.name);

    const existingBadges = new Set(profile.badges ?? []);
    const newBadges = earnedBadges.filter(badge => !existingBadges.has(badge));

    if (newBadges.length > 0) {
      await ctx.db.patch(profile._id, {
        badges: [...(profile.badges ?? []), ...newBadges],
      });
    }

    return { personality, newBadges };
  },
});

export const addQuestions = mutation({
  args: {},
  handler: async (ctx) => {
    const existingQuestions = await ctx.db.query("questions").collect();
    for (const question of existingQuestions) {
      await ctx.db.delete(question._id);
    }

    const questions = [
      {
        text_ar: "هل تستمتع بحل المشكلات المنطقية؟",
        text_en: "Do you enjoy solving logical problems?",
        order: 0,
      },
      {
        text_ar: "هل أنت مهتم بكيفية عمل التكنولوجيا؟",
        text_en: "Are you interested in how technology works?",
        order: 1,
      },
      {
        text_ar: "هل تفضل إنشاء حلول جديدة للمشكلات؟",
        text_en: "Do you prefer creating new solutions to problems?",
        order: 2,
      },
      {
        text_ar: "هل تستمتع بتعلم لغات وأدوات جديدة؟",
        text_en: "Do you enjoy learning new languages and tools?",
        order: 3,
      },
      {
        text_ar: "هل تفضل العمل على المشاريع التقنية؟",
        text_en: "Do you prefer working on technical projects?",
        order: 4,
      },
      {
        text_ar: "هل تجد متعة في تحسين الحلول؟",
        text_en: "Do you find joy in improving solutions?",
        order: 5,
      },
      {
        text_ar: "هل أنت مهتم بتحليل البيانات والأنماط؟",
        text_en: "Are you interested in analyzing data and patterns?",
        order: 6,
      },
      {
        text_ar: "هل تستمتع بالعمل في فريق تقني؟",
        text_en: "Do you enjoy working in a technical team?",
        order: 7,
      },
      {
        text_ar: "هل تفضل قضاء الوقت في تعلم البرمجة؟",
        text_en: "Do you prefer spending time learning programming?",
        order: 8,
      },
      {
        text_ar: "هل ترى نفسك تعمل في التقنية في المستقبل؟",
        text_en: "Do you see yourself working in tech in the future?",
        order: 9,
      },
      {
        text_ar: "هل تستمتع بتجربة التقنيات الجديدة؟",
        text_en: "Do you enjoy experimenting with new technologies?",
        order: 10,
      },
      {
        text_ar: "هل تفكر في المساهمة في مشاريع المصدر المفتوح؟",
        text_en: "Do you think about contributing to open source projects?",
        order: 11,
      },
      {
        text_ar: "هل أنت مهتم بتعلم الأمن السيبراني؟",
        text_en: "Are you interested in learning about cybersecurity?",
        order: 12,
      },
      {
        text_ar: "هل تفكر في إنشاء تطبيقاتك الخاصة؟",
        text_en: "Do you think about creating your own applications?",
        order: 13,
      },
      {
        text_ar: "هل أنت مهتم بالذكاء الاصطناعي والتعلم الآلي؟",
        text_en: "Are you interested in AI and machine learning?",
        order: 14,
      }
    ];

    for (const question of questions) {
      await ctx.db.insert("questions", question);
    }

    const badges = await ctx.db.query("badges").collect();
    if (badges.length === 0) {
      await ctx.runMutation(api.badges.initializeBadges);
    }
  },
});
