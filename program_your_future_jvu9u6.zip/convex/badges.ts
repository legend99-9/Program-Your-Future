import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const initializeBadges = mutation({
  args: {},
  handler: async (ctx) => {
    const existingBadges = await ctx.db.query("badges").collect();
    for (const badge of existingBadges) {
      await ctx.db.delete(badge._id);
    }

    const badges = [
      {
        name: "Beginner",
        name_ar: "Beginner",
        description: "Completed your first quiz",
        description_ar: "Completed your first quiz",
        icon: "🌱",
        requiredScore: 0,
        type: "score",
      },
      {
        name: "Enthusiast",
        name_ar: "Enthusiast",
        description: "Got a high score in the quiz",
        description_ar: "Got a high score in the quiz",
        icon: "🔥",
        requiredScore: 80,
        type: "score",
      },
      {
        name: "Future Programmer",
        name_ar: "Future Programmer",
        description: "Achieved the highest possible score",
        description_ar: "Achieved the highest possible score",
        icon: "⭐",
        requiredScore: 95,
        type: "score",
      },
      {
        name: "Explorer",
        name_ar: "Explorer",
        description: "Completed 3 quizzes",
        description_ar: "Completed 3 quizzes",
        icon: "🎯",
        requiredCompletions: 3,
        type: "completions",
      },
      {
        name: "Professional",
        name_ar: "Professional",
        description: "Completed 5 quizzes",
        description_ar: "Completed 5 quizzes",
        icon: "🏆",
        requiredCompletions: 5,
        type: "completions",
      },
      {
        name: "Expert",
        name_ar: "Expert",
        description: "Completed 10 quizzes",
        description_ar: "Completed 10 quizzes",
        icon: "👑",
        requiredCompletions: 10,
        type: "completions",
      }
    ];

    for (const badge of badges) {
      await ctx.db.insert("badges", badge);
    }
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("badges").collect();
  },
});

export const getUserBadges = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", q => q.eq("userId", userId))
      .first();

    return profile?.badges ?? [];
  },
});

export const getBadgeProgress = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const badges = await ctx.db.query("badges").collect();
    const responses = await ctx.db
      .query("responses")
      .withIndex("by_user", q => q.eq("userId", userId))
      .collect();

    const completions = responses.length;
    const bestScore = Math.max(...responses.map(r => ((3 - (r.score ?? 0)) / 2) * 100));

    return badges.map(badge => {
      let progress = 0;
      if (badge.type === "score" && badge.requiredScore !== undefined) {
        progress = Math.min(100, (bestScore / badge.requiredScore) * 100);
      } else if (badge.type === "completions" && badge.requiredCompletions !== undefined) {
        progress = Math.min(100, (completions / badge.requiredCompletions) * 100);
      }
      return { ...badge, progress };
    });
  },
});
